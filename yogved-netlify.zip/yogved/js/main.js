(function(){
const WA='918370919191';
const nav=document.getElementById('nav');
const onScroll=()=>nav.classList.toggle('scrolled',window.scrollY>50);
onScroll();window.addEventListener('scroll',onScroll,{passive:true});
document.querySelectorAll('.navbar-nav a').forEach(a=>a.addEventListener('click',()=>{
  const c=document.getElementById('menu');if(c.classList.contains('show'))bootstrap.Collapse.getInstance(c).hide();}));
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('show');io.unobserve(e.target)}}),{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>io.observe(el));
document.querySelectorAll('img').forEach(i=>i.addEventListener('error',()=>{i.style.display='none'}));
const d=new Date().toISOString().split('T')[0];
document.querySelectorAll('input[type=date]').forEach(i=>i.min=d);
const f=document.getElementById('enquiry');
function msg(){const v=n=>encodeURIComponent(f.elements[n].value.trim());
return `Hello Yogved Hospitality & Resort, I would like to enquire about a stay.%0AName: ${v('name')}%0APhone: ${v('phone')}%0ACheck-in: ${v('checkin')}%0ACheck-out: ${v('checkout')}%0AGuests: ${v('guests')}%0ARoom: ${v('room')}%0AMessage: ${v('message')}`}
f.addEventListener('submit',async e=>{
  e.preventDefault();
  if(!f.checkValidity()){f.classList.add('was-validated');return}
  if(new Date(f.elements.checkout.value)<=new Date(f.elements.checkin.value)){alert('Check-out must be after check-in.');return}
  const url=`https://wa.me/${WA}?text=${msg()}`;
  const body=new URLSearchParams(new FormData(f)).toString();
  window.open(url,'_blank','noopener');
  try{await fetch('/',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body})}catch(_){}
  document.getElementById('ok').classList.remove('d-none');f.reset();f.classList.remove('was-validated');
});
})();
