Add photos here (JPG/WebP, compressed): hero.jpg (1920x1080), about.jpg, yoga.jpg, room-1..3.jpg, gallery-1..8.jpg
Missing images fall back to elegant gradient blocks.
